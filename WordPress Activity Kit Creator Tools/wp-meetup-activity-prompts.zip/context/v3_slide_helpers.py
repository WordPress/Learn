#!/usr/bin/env python3
"""
v3_slide_helpers.py — Shared canonical helpers for all WordPress Meetup Activity slide decks.
Import with: from v3_slide_helpers import *

Design system version: v3 (2026-05)
Canonical reference: build_managing_wp_with_ai_slides.py
"""

from lxml import etree
from pptx import Presentation
from pptx.util import Emu, Pt
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN
from pptx.oxml.ns import qn

# ── Slide canvas ─────────────────────────────────────────────────────────────
W = Emu(12192000)   # 13.33" (16:9)
H = Emu(6858000)    # 7.5"

# ── Color palette ─────────────────────────────────────────────────────────────
BLUE      = RGBColor(0x38, 0x58, 0xE9)   # primary accent
BLUE_TINT = RGBColor(0xEE, 0xF1, 0xFD)   # facilitator tip bg
CAUTION   = RGBColor(0x96, 0x70, 0x0A)   # note/important accent bar
CAUTION_T = RGBColor(0xFF, 0xF8, 0xE1)   # note/important bg
SUCCESS   = RGBColor(0x00, 0x70, 0x17)   # success accent bar
SUCCESS_T = RGBColor(0xF0, 0xFF, 0xF4)   # success bg
BLACK     = RGBColor(0x1E, 0x1E, 0x1E)   # body text + dark bg
MUTED     = RGBColor(0x75, 0x75, 0x75)   # captions on light bg
MUTED_DK  = RGBColor(0xAA, 0xAA, 0xAA)  # captions/subtitles on dark bg
WHITE     = RGBColor(0xFF, 0xFF, 0xFF)
LGREY     = RGBColor(0xF0, 0xF0, 0xF0)   # code bg, light card bg
RED       = RGBColor(0xE6, 0x50, 0x54)   # error/danger

# Legacy aliases so old scripts that import * still work
WP_BLUEBERRY = BLUE
WP_LICORICE  = BLACK
WP_WHITE     = WHITE
WP_LBLUE     = BLUE_TINT
WP_MID_GRAY  = MUTED
WP_DARK      = BLACK
WP_LIGHT     = LGREY
WP_WARN_BG   = CAUTION_T
WP_WARN_BDR  = CAUTION

def inches(x): return Emu(int(x * 914400))


# ── Low-level helpers ─────────────────────────────────────────────────────────

def set_bg(slide, color):
    fill = slide.background.fill
    fill.solid()
    fill.fore_color.rgb = color


def add_rect(slide, left, top, width, height, color, line=False):
    shape = slide.shapes.add_shape(1, left, top, width, height)
    shape.fill.solid()
    shape.fill.fore_color.rgb = color
    if not line:
        shape.line.fill.background()
    return shape


def txb(slide, left, top, width, height):
    """Zero-margin text box."""
    box = slide.shapes.add_textbox(left, top, width, height)
    tf  = box.text_frame
    tf.word_wrap = True
    tf.margin_left = tf.margin_right = tf.margin_top = tf.margin_bottom = Emu(0)
    return tf, box


# Pending facilitator tips per slide — flushed into notes by set_notes()
_pending_tips: dict = {}


def set_notes(slide, text):
    """Set speaker notes, automatically appending any pending facilitator tips."""
    tips = _pending_tips.pop(id(slide), [])
    full = text
    if tips:
        full = text + ("\n\n" if text else "") + "\n".join(tips)
    tf = slide.notes_slide.notes_text_frame
    tf.text = full


# ── XML paragraph helpers ─────────────────────────────────────────────────────

def _lnSpc(para, pct=120):
    """Set 1.2× (120%) line spacing via XML."""
    pPr = para._p.get_or_add_pPr()
    for el in pPr.findall(qn('a:lnSpc')):
        pPr.remove(el)
    lnSpc = etree.SubElement(pPr, qn('a:lnSpc'))
    etree.SubElement(lnSpc, qn('a:spcPct')).set('val', str(pct * 1000))


def _anchor_ctr(shape_or_tf):
    """Set bodyPr anchor='ctr' for vertical centering. Accepts shape or text frame."""
    if shape_or_tf is None:
        return
    txBody = (shape_or_tf.text_frame._txBody
              if hasattr(shape_or_tf, 'text_frame')
              else shape_or_tf._txBody)
    bodyPr = txBody.find(qn('a:bodyPr'))
    if bodyPr is not None:
        bodyPr.set('anchor', 'ctr')


def _autonumber_pPr(para, num=1, mar_emu=274638):
    """Blue arabicPeriod buAutoNum with hanging indent. num > 1 sets startAt."""
    pPr = para._p.get_or_add_pPr()
    pPr.set('marL', str(mar_emu))
    pPr.set('indent', str(-mar_emu))
    for tag in ['a:buClr','a:buClrTx','a:buFont','a:buFontTx',
                'a:buChar','a:buAutoNum','a:buNone']:
        for el in pPr.findall(qn(tag)):
            pPr.remove(el)
    clr = etree.SubElement(pPr, qn('a:buClr'))
    etree.SubElement(clr, qn('a:srgbClr')).set('val', '3858E9')
    fnt = etree.SubElement(pPr, qn('a:buFont'))
    fnt.set('typeface', 'Arial')
    auto = etree.SubElement(pPr, qn('a:buAutoNum'))
    auto.set('type', 'arabicPeriod')
    if num > 1:
        auto.set('startAt', str(num))


def _bullet_pPr(para, mar_emu=274638):
    """buChar bullet (•) with hanging indent."""
    pPr = para._p.get_or_add_pPr()
    pPr.set('marL', str(mar_emu))
    pPr.set('indent', str(-mar_emu))
    for tag in ['a:buClr','a:buClrTx','a:buFont','a:buFontTx',
                'a:buChar','a:buAutoNum','a:buNone']:
        for el in pPr.findall(qn(tag)):
            pPr.remove(el)
    fnt = etree.SubElement(pPr, qn('a:buFont'))
    fnt.set('typeface', 'Arial')
    char = etree.SubElement(pPr, qn('a:buChar'))
    char.set('char', '•')


# ── Run helpers ───────────────────────────────────────────────────────────────

def _run(para, text, size=16, bold=False, italic=False, color=None):
    run = para.add_run()
    run.text = text
    run.font.name  = 'Arial'
    run.font.size  = Pt(size)
    run.font.bold  = bold
    run.font.italic = italic
    if color:
        run.font.color.rgb = color
    return run


def first_para(tf, text='', size=16, bold=False, italic=False,
               color=None, align=PP_ALIGN.LEFT, lspc=120):
    p = tf.paragraphs[0]
    p.alignment = align
    _lnSpc(p, lspc)
    return _run(p, text, size=size, bold=bold, italic=italic, color=color)


def add_para(tf, text='', size=16, bold=False, italic=False,
             color=None, align=PP_ALIGN.LEFT, lspc=120, spc_bef=None):
    p = tf.add_paragraph()
    p.alignment = align
    if spc_bef is not None:
        p.space_before = Pt(spc_bef)
    _lnSpc(p, lspc)
    return _run(p, text, size=size, bold=bold, italic=italic, color=color)


def hyperlink_run(slide, para, text, url, size=16, color=None, bold=False):
    """Hyperlinked text run. Uses XML a:hlinkClick (run.hyperlink.address fails in textboxes).

    Color is injected directly as <a:solidFill> in the run's rPr XML so it cannot be
    overridden by the theme's hyperlink color (which renderers like LibreOffice otherwise
    apply regardless of run.font.color.rgb).
    """
    rId = slide.part.relate_to(
        url,
        'http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink',
        is_external=True
    )
    run = para.add_run()
    run.text = text
    run.font.name = 'Arial'
    run.font.size = Pt(size)
    run.font.bold = bold
    rPr = run._r.get_or_add_rPr()
    if color:
        # Remove any existing fill elements to avoid conflicts
        for fill_tag in ('a:solidFill', 'a:noFill', 'a:gradFill', 'a:pattFill', 'a:blipFill'):
            for existing in rPr.findall(qn(fill_tag)):
                rPr.remove(existing)
        # Inject solidFill directly into rPr XML — this overrides the theme hyperlink color
        solid = etree.SubElement(rPr, qn('a:solidFill'))
        srgb  = etree.SubElement(solid, qn('a:srgbClr'))
        srgb.set('val', str(color))  # RGBColor.__str__ returns 6-char hex e.g. 'FFFFFF'
    hl = etree.SubElement(rPr, qn('a:hlinkClick'))
    hl.set(qn('r:id'), rId)
    return run


# ── Layout helpers ────────────────────────────────────────────────────────────

def breadcrumb(slide, text, dark=False):
    """Small navigation label at top-left. Replaces old slide_label bar."""
    tf, _ = txb(slide, inches(0.55), inches(0.08), inches(10.0), inches(0.30))
    p = tf.paragraphs[0]
    _run(p, text, size=13, color=MUTED_DK if dark else MUTED)


def slide_title(slide, text, dark=False):
    """Standard content slide title — 28pt Bold BLUE."""
    tf, _ = txb(slide, inches(0.55), inches(0.38), inches(12.0), inches(0.70))
    first_para(tf, text, size=28, bold=True,
               color=WHITE if dark else BLUE, lspc=110)


def section_header(slide, badge_text, title_text):
    """Plain bold number + bold BLUE title — same size/position as slide_title (28pt, y=0.38")."""
    tf, _ = txb(slide, inches(0.55), inches(0.38), W - inches(1.1), inches(0.70))
    p = tf.paragraphs[0]
    _lnSpc(p, 110)
    _run(p, badge_text + '  ', size=28, bold=True, color=BLUE)
    _run(p, title_text, size=28, bold=True, color=BLUE)


# ── List item helpers ─────────────────────────────────────────────────────────

def num_item(slide, n, text, top, left=None, width=None, size=20, h=None, bold=False):
    """Numbered list item using buAutoNum. Returns top + 0.65" for next item."""
    if left  is None: left  = inches(0.55)
    if width is None: width = W - left - inches(0.55)
    if h     is None: h     = inches(0.55)
    tf, _ = txb(slide, left, top, width, h)
    p = tf.paragraphs[0]
    _lnSpc(p, 120)
    _autonumber_pPr(p, n)
    _run(p, text, size=size, bold=bold, color=BLACK)
    return top + inches(0.65)


def bul_item(slide, text, top, left=None, width=None, size=20, bold=False, h=None, color=None):
    """Bullet list item using buChar •. Returns top + 0.65" for next item."""
    if left  is None: left  = inches(0.55)
    if width is None: width = W - left - inches(0.55)
    if h     is None: h     = inches(0.55)
    tf, _ = txb(slide, left, top, width, h)
    p = tf.paragraphs[0]
    _lnSpc(p, 120)
    _bullet_pPr(p)
    _run(p, text, size=size, bold=bold, color=color or BLACK)
    return top + inches(0.65)


# ── Callout helpers ───────────────────────────────────────────────────────────

def _callout_box(slide, text, top, width, bg, accent, label, h=None):
    """Shared callout box. Pass h to override the default height (inches(0.75)).
    Use a taller h when the text content wraps to more than one line."""
    if h is None:
        h = inches(0.75)
    add_rect(slide, inches(0.55), top, width, h, bg)
    add_rect(slide, inches(0.55), top, inches(0.065), h, accent)
    tf, _ = txb(slide,
                inches(0.55) + inches(0.15), top,
                width - inches(0.15), h)
    _anchor_ctr(tf)
    p = tf.paragraphs[0]
    _lnSpc(p, 120)
    _run(p, label + ':  ', size=15, bold=True, color=accent)
    _run(p, text, size=15, color=BLACK)


def tip_callout(slide, text, top, width=None, label='Facilitator tip'):
    """Facilitator tip — stored in speaker notes only, never rendered on slide.
    Returns top unchanged (no space consumed). Flushed by set_notes()."""
    _pending_tips.setdefault(id(slide), []).append(f"💡 {label}: {text}")
    return top


def note_callout(slide, text, top, width=None, label='Note', h=None):
    """Amber note/important box. Pass h=inches(N) for multi-line text."""
    if width is None:
        width = W - inches(0.55) - inches(0.55)
    _callout_box(slide, text, top, width, CAUTION_T, CAUTION, label, h=h)


def success_callout(slide, text, top, width=None, label='Stretch goal', h=None):
    """Green success/stretch goal box. Pass h=inches(N) for multi-line text."""
    if width is None:
        width = W - inches(0.55) - inches(0.55)
    _callout_box(slide, text, top, width, SUCCESS_T, SUCCESS, label, h=h)


# ── Code block helper ─────────────────────────────────────────────────────────

def code_block(slide, lines, top, left=None, width=None):
    """Grey code block. lines = list of strings. Returns bottom y."""
    if left  is None: left  = inches(0.55)
    if width is None: width = W - left - inches(0.55)
    n_lines = len(lines)
    h = inches(0.20) + n_lines * inches(0.32)   # 0.20" padding + 0.32"/line at 14pt/1.2×
    add_rect(slide, left, top, width, h, LGREY)
    tf, _ = txb(slide, left + inches(0.25), top + inches(0.12),
                width - inches(0.50), h - inches(0.24))
    first_para(tf, lines[0], size=14, color=BLACK, lspc=120)
    for line in lines[1:]:
        add_para(tf, line, size=14, color=BLACK, lspc=120, spc_bef=0)
    return top + h


# ── Resources table ───────────────────────────────────────────────────────────

def _cell_borders(cell, color_hex="CCCCCC", width=9525):
    """Thin border on all four sides of a table cell."""
    tc = cell._tc
    tcPr = tc.get_or_add_tcPr()
    for side in ("lnL", "lnR", "lnT", "lnB"):
        for el in tcPr.findall(qn(f"a:{side}")):
            tcPr.remove(el)
        ln = etree.Element(qn(f"a:{side}"))
        ln.set("w", str(width)); ln.set("cap", "flat"); ln.set("cmpd", "sng")
        sf = etree.SubElement(ln, qn("a:solidFill"))
        clr = etree.SubElement(sf, qn("a:srgbClr"))
        clr.set("val", color_hex)
        tcPr.append(ln)


def resources_table(slide, y_start, resources, row_h=None):
    """Two-column resources table: label (col 1) | clickable URL (col 2).
    resources = [(label, url), ...]
    Alternating BLUE_TINT / WHITE rows. Label 14pt BLACK; URL 12pt BLUE hyperlink."""
    if row_h is None:
        row_h = inches(0.54)
    n = len(resources)
    tbl_shape = slide.shapes.add_table(n, 2, inches(0.5), y_start,
                                       inches(11.3), row_h * n)
    tbl = tbl_shape.table
    tbl.columns[0].width = inches(6.8)
    tbl.columns[1].width = inches(4.5)
    for i, (label, url) in enumerate(resources):
        fill = BLUE_TINT if i % 2 == 0 else WHITE
        for j in range(2):
            cell = tbl.cell(i, j)
            cell.fill.solid(); cell.fill.fore_color.rgb = fill
            cell.margin_left = Emu(114300); cell.margin_right = Emu(114300)
            cell.margin_top = Emu(76200);   cell.margin_bottom = Emu(76200)
            _cell_borders(cell)
        c0, c1 = tbl.cell(i, 0), tbl.cell(i, 1)
        c0.text_frame.word_wrap = True
        p0 = c0.text_frame.paragraphs[0]
        _lnSpc(p0, 120)
        r0 = p0.add_run(); r0.text = label
        r0.font.name = "Arial"; r0.font.size = Pt(14)
        r0.font.bold = False; r0.font.color.rgb = BLACK
        c1.text_frame.word_wrap = True
        p1 = c1.text_frame.paragraphs[0]
        _lnSpc(p1, 120)
        hyperlink_run(slide, p1, url, url, size=12, color=BLUE)


# ═══════════════════════════════════════════════════════════════════════════════
# v4 Template helpers — canonical design for all new decks (2026-05+)
#
# Title slide:  dark bg (#1E1E1E) + blue LEFT bar + inline subtitle text
# White slides: thin blue TOP bar + full-width blue SECTION BAR (content slides)
#               OR thin blue TOP bar + title (agenda/table/debrief/resources slides)
# Steps:        inline numbered paragraphs — bold BLUE number, tab, BLACK body
# Tip:          visible gray box on slide (no floating badge shapes)
#
# Canonical reference: build_content_creation_slides.py
# ═══════════════════════════════════════════════════════════════════════════════

LAVENDER  = RGBColor(0xE8, 0xEA, 0xFD)   # agenda/debrief row bg
GREY_TIP  = RGBColor(0xF0, 0xF1, 0xF8)   # visible tip box bg


def top_bar(slide, h=None):
    """Thin blue accent bar across the very top of all white slides."""
    if h is None: h = inches(0.08)
    add_rect(slide, Emu(0), Emu(0), W, h, BLUE)


def left_bar(slide, w=None):
    """Blue accent bar along the left side of dark title slides."""
    if w is None: w = inches(0.32)
    add_rect(slide, Emu(0), Emu(0), w, H, BLUE)


def slide_title_v4(slide, text):
    """Title for white non-section slides (agenda, table, debrief, resources).
    top_bar() must be called first. Returns recommended content_top y."""
    tf, _ = txb(slide, inches(0.55), inches(0.20), inches(12.0), inches(0.55))
    first_para(tf, text, size=28, bold=True, color=BLUE, lspc=110)
    return inches(0.95)   # recommended content top (title bottom + 0.20" gap)


def section_bar(slide, title, supertitle=None):
    """Full-width BLUE bar with white title. Adds top_bar automatically.
    supertitle: 'Part N  ·  X minutes' shown above the bar in gray.
    Returns recommended content_top y."""
    top_bar(slide)
    bar_y = inches(0.38) if supertitle else inches(0.12)
    bar_h = inches(0.68)
    if supertitle:
        tf, _ = txb(slide, inches(0.65), inches(0.10), inches(11.0), inches(0.28))
        first_para(tf, supertitle, size=12, color=MUTED)
    add_rect(slide, Emu(0), bar_y, W, bar_h, BLUE)
    tf, _ = txb(slide, inches(0.65), bar_y, W - inches(0.70), bar_h)
    _anchor_ctr(tf)
    first_para(tf, title, size=24, bold=True, color=WHITE, lspc=110)
    return bar_y + bar_h + inches(0.22)   # recommended content top


def _add_tab_stop(para, pos_emu):
    """Add a left-aligned tab stop at pos_emu from the text-frame left edge."""
    pPr = para._p.get_or_add_pPr()
    tabLst = pPr.find(qn('a:tabLst'))
    if tabLst is None:
        tabLst = etree.SubElement(pPr, qn('a:tabLst'))
    tab = etree.SubElement(tabLst, qn('a:tab'))
    tab.set('pos', str(int(pos_emu)))
    tab.set('algn', 'l')


def num_step_para(p, n, body, size=16, spc_bef=0, slide=None):
    """Configure paragraph p as one numbered step.
    body: str  OR  list of parts, each part is:
          str                   → plain black text
          ('bold', text)        → bold black text
          ('link', url, text)   → hyperlink (requires slide kwarg)
    Number 'N.' is bold BLUE; body text is BLACK.
    """
    TAB = int(inches(0.45))
    pPr = p._p.get_or_add_pPr()
    pPr.set('marL', str(TAB))
    pPr.set('indent', str(-TAB))
    if spc_bef:
        p.space_before = Pt(spc_bef)
    _lnSpc(p, 130)
    _add_tab_stop(p, TAB)
    _run(p, f"{n}.", size=size, bold=True, color=BLUE)
    _run(p, "\t", size=size, color=BLACK)
    if isinstance(body, str):
        _run(p, body, size=size, color=BLACK)
    else:
        for part in body:
            if isinstance(part, str):
                _run(p, part, size=size, color=BLACK)
            elif part[0] == 'bold':
                _run(p, part[1], size=size, bold=True, color=BLACK)
            elif part[0] == 'link' and slide is not None:
                hyperlink_run(slide, p, part[2], part[1], size=size, color=BLUE)
            else:
                _run(p, part[-1], size=size, color=BLACK)


def num_steps(slide, steps, top, left=None, size=16, spc_bef=10):
    """Add numbered steps as inline paragraphs in one text frame.
    steps: list of body values accepted by num_step_para.
    Returns bottom y of the text frame."""
    if left is None: left = inches(0.65)
    width = W - left - inches(0.55)
    h = H - top - inches(1.0)   # generous — auto-expand
    tf, _ = txb(slide, left, top, width, h)
    for i, step in enumerate(steps):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        num_step_para(p, i + 1, step, size=size,
                      spc_bef=0 if i == 0 else spc_bef, slide=slide)
    return top + h


def tip_box(slide, text, top=None, left=None, width=None, h=None,
            label='Facilitator note'):
    """Facilitator note — stored in speaker notes ONLY, never rendered on slide.
    Identical behaviour to tip_callout(). top is returned unchanged (no space consumed).
    Flushed to notes automatically when set_notes() is called on this slide.

    For participant-facing callouts visible on slide, use note_callout() (amber)
    or success_callout() (green) instead.
    """
    _pending_tips.setdefault(id(slide), []).append(f"💡 {label}: {text}")
    return top


def agenda_table(slide, rows, top, left=None):
    """Agenda overview rows — lavender cards, bold title left, blue time right.
    rows: list of (title_str, time_str).  'Part N' rows are bold; others are not."""
    if left is None: left = inches(0.50)
    ROW_H  = inches(0.68)
    GAP    = inches(0.07)
    width  = W - left - inches(0.50)
    for i, (title, time_str) in enumerate(rows):
        y = top + i * (ROW_H + GAP)
        shape = slide.shapes.add_shape(1, left, y, width, ROW_H)
        shape.fill.solid(); shape.fill.fore_color.rgb = LAVENDER
        shape.line.fill.background()
        # title
        tf, _ = txb(slide, left + inches(0.20), y, width - inches(1.10), ROW_H)
        _anchor_ctr(tf)
        p = tf.paragraphs[0]; _lnSpc(p, 120)
        _run(p, title, size=16, bold=title.startswith('Part'), color=BLACK)
        # time
        tf2, _ = txb(slide, left + width - inches(0.95), y, inches(0.90), ROW_H)
        _anchor_ctr(tf2)
        p2 = tf2.paragraphs[0]; p2.alignment = PP_ALIGN.RIGHT; _lnSpc(p2, 120)
        _run(p2, time_str, size=16, bold=True, color=BLUE)


def discussion_rows(slide, items, top, left=None):
    """Debrief / discussion rows — lavender cards, italic BLUE number, black text."""
    if left is None: left = inches(0.50)
    ROW_H  = inches(0.68)
    GAP    = inches(0.07)
    width  = W - left - inches(0.50)
    for i, item in enumerate(items):
        y = top + i * (ROW_H + GAP)
        shape = slide.shapes.add_shape(1, left, y, width, ROW_H)
        shape.fill.solid(); shape.fill.fore_color.rgb = LAVENDER
        shape.line.fill.background()
        # number
        tf, _ = txb(slide, left + inches(0.18), y, inches(0.38), ROW_H)
        _anchor_ctr(tf)
        p = tf.paragraphs[0]; p.alignment = PP_ALIGN.CENTER; _lnSpc(p, 120)
        _run(p, str(i + 1), size=18, bold=True, color=BLUE)
        # text
        tf2, _ = txb(slide, left + inches(0.65), y, width - inches(0.75), ROW_H)
        _anchor_ctr(tf2)
        p2 = tf2.paragraphs[0]; _lnSpc(p2, 120)
        _run(p2, item, size=16, color=BLACK)


def data_table(slide, headers, rows, top, left=None, col_widths=None,
               row_h=None, header_col=False, body_size=15):
    """Generic table: blue header row + alternating LAVENDER/WHITE body rows.
    headers:    list of str
    rows:       list of lists of str
    col_widths: list of Emu values (must sum ≈ content width)
    header_col: first col in body rows gets bold + LAVENDER bg (comparison tables)
    """
    if left    is None: left   = inches(0.50)
    if row_h   is None: row_h  = inches(0.60)
    total_w = W - left - inches(0.50)
    ncols   = len(headers)
    if col_widths is None:
        unit = Emu(int(total_w / ncols))
        col_widths = [unit] * ncols
        col_widths[-1] = Emu(int(total_w) - sum(int(c) for c in col_widths[:-1]))
    nrows_total = len(rows) + 1
    tbl_shape = slide.shapes.add_table(
        nrows_total, ncols, left, top, total_w, row_h * nrows_total)
    tbl = tbl_shape.table
    for j, w in enumerate(col_widths):
        tbl.columns[j].width = w
    # Header row
    for j, hdr in enumerate(headers):
        cell = tbl.cell(0, j)
        cell.fill.solid(); cell.fill.fore_color.rgb = BLUE
        cell.margin_left = cell.margin_right = Emu(114300)
        cell.margin_top  = cell.margin_bottom = Emu(76200)
        _cell_borders(cell, '3858E9')
        p = cell.text_frame.paragraphs[0]; _lnSpc(p, 120)
        r = p.add_run(); r.text = hdr
        r.font.name = 'Arial'; r.font.size = Pt(15)
        r.font.bold = True; r.font.color.rgb = WHITE
    # Body rows
    for i, row in enumerate(rows):
        row_bg = LAVENDER if i % 2 == 0 else WHITE
        for j, val in enumerate(row):
            cell = tbl.cell(i + 1, j)
            use_bg = LAVENDER if (header_col and j == 0) else row_bg
            cell.fill.solid(); cell.fill.fore_color.rgb = use_bg
            cell.margin_left = cell.margin_right = Emu(114300)
            cell.margin_top  = cell.margin_bottom = Emu(76200)
            cell.text_frame.word_wrap = True
            _cell_borders(cell)
            p = cell.text_frame.paragraphs[0]; _lnSpc(p, 120)
            r = p.add_run(); r.text = val
            r.font.name = 'Arial'; r.font.size = Pt(body_size)
            r.font.bold = bool(header_col and j == 0)
            r.font.color.rgb = BLACK

