# WordPress Meetup Activity Creator — Knowledge Base

This file documents the authoritative resources for activity research and design. Always prefer official WordPress sources over third-party commentary.

---

## Official WordPress Resources

| Resource | URL | When to use |
|----------|-----|-------------|
| Learn WordPress | https://learn.wordpress.org/ | Find existing lessons and tutorials on the topic; check for gaps before drafting objectives |
| WordPress Documentation | https://wordpress.org/documentation/ | End-user documentation for features; use for step verification |
| WordPress Developer Resources | https://developer.wordpress.org/ | Theme, plugin, block, and REST API reference; use for developer-level activities |
| WordPress Support Forums | https://wordpress.org/support/forums/ | Common participant pain points and real-world issues to include in facilitator tips |
| WordPress Download | https://wordpress.org/download/ | Version history, release notes |
| WordPress Playground | https://playground.wordpress.net | Default activity environment; always test steps here before publishing |

---

## Brand, Style, and Promotional Guidelines

| Resource | URL | When to use |
|----------|-----|-------------|
| Style Guide & Brand Book | https://make.wordpress.org/marketing/handbook/resources/style-guide-and-brand-book/ | Voice, tone, naming conventions, logo usage |
| Make WordPress Training — Promotional Guidelines | https://make.wordpress.org/training/handbook/guidelines/promotional-guidelines/ | Rules for plugin/tool mentions; "2–3 alternatives" requirement |
| WordPress Design System (Figma) | https://www.figma.com/community/file/1436359662053949167/wordpress-design-system | Color tokens, component patterns, typography |

---

## Make WordPress Team Handbooks

Use these to understand contributor workflows and team structure when building Contributor Onboarding or team-specific activities.

| Team | URL |
|------|-----|
| Make WordPress (hub) | https://make.wordpress.org/ |
| Core | https://make.wordpress.org/core/handbook/ |
| Design | https://make.wordpress.org/design/handbook/ |
| Accessibility | https://make.wordpress.org/accessibility/ |
| Training | https://make.wordpress.org/training/handbook/ |
| Documentation | https://make.wordpress.org/docs/handbook/ |
| Marketing | https://make.wordpress.org/marketing/handbook/ |
| Support | https://make.wordpress.org/support/handbook/ |

---

## Source Quality Rules

Apply these when evaluating sources for inclusion in a facilitator guide.

| Signal | Action |
|--------|--------|
| Official wordpress.org or make.wordpress.org URL | Preferred. Include with no flag. |
| Official plugin page on wordpress.org/plugins | Acceptable for plugin-specific steps. |
| learn.wordpress.org lesson or tutorial | Preferred for further reading. |
| Third-party blog post (WPBeginner, Kinsta, Elegant Themes, etc.) | Use only if no official source covers the topic. Note it as third-party. Do not use for factual claims. |
| Paywalled content | Do not include. |
| Content older than 3 years | Verify it still applies to current WordPress. Flag if uncertain. |
| URL returns 4xx/5xx | Do not include. Find an alternative. |

---

## Design System Color Reference

These are the canonical WordPress Design System values. Never use the old `#0073AA` WordPress blue.

| Name | Hex | Usage |
|------|-----|-------|
| Blueberry | `#3858E9` | Primary accent, headings, step numbers, hyperlinks |
| Licorice | `#1E1E1E` | Body text, dark backgrounds |
| Pomegranate | `#E65054` | Error / danger callouts only |
| Jalapeno | `#007017` | Success / stretch goal callouts |
| Banana | `#FCB900` | Highlight badges (use sparingly) |

Full color and typography rules: see `STYLE_GUIDE.md`.

---

## Accessibility Standards

All activities must be designed with accessibility in mind, not as a final check.

| Standard | URL |
|----------|-----|
| WCAG 2.2 (Web Content Accessibility Guidelines) | https://www.w3.org/WAI/standards-guidelines/wcag/ |
| Make WordPress Accessible | https://make.wordpress.org/accessibility/ |
| Equalize Digital Accessibility Checker | https://wordpress.org/plugins/accessibility-checker/ |
| Sa11y (Toronto Metropolitan University) | https://wordpress.org/plugins/sa11y/ |
| Editoria11y | https://wordpress.org/plugins/editoria11y-accessibility-checker/ |
