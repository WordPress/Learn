# Hands-On WordPress Meetup Activity Library — Style Guide

**Scope:** All facilitator guide (.docx) and slide deck (.pptx) outputs in this library.
**Canonical reference:** The eCommerce with WooCommerce files are the gold-standard implementation. When in doubt, match them.

---

## 1. COLOR PALETTE

Use these hex values consistently across both docx and pptx scripts. Define them as named constants at the top of every build script.

| Constant name     | Hex       | Usage |
|-------------------|-----------|-------|
| `C_BLUEBERRY`     | `3858E9`  | Primary accent: headings, callout borders, hyperlinks, step numbers, part headers |
| `C_POMEGRANATE`   | `E65054`  | Error / danger callouts only |
| `C_BANANA`        | `FCB900`  | Highlight badges, optional decoration |
| `C_JALAPENO`      | `007017`  | Success / stretch callouts, beginner-level markers |
| `C_LICORICE`      | `1E1E1E`  | Primary body text, H2 headings, dark backgrounds |
| `C_WHITE`         | `FFFFFF`  | Text on dark backgrounds, cell fills |
| `C_LBLUE`         | `EEF1FD`  | Default callout fill, meta/overview table accent cells |
| `C_LGREY`         | `F5F5F5`  | Light backgrounds (overview table value cells) |
| `C_MGREY`         | `CCCCCC`  | Divider lines, table borders |
| `C_MID_GRAY`      | `595959`  | Supporting/caption text (sources notes, subtitles) |
| `MUTED_DK`        | `AAAAAA`  | **Slides only:** secondary/caption text on **white** backgrounds only. ⚠️ NEVER use on dark/black backgrounds — fails WCAG AA. All text on dark slides must be `WHITE`. |
| `C_WARNING_FILL`  | `FFF8E1`  | Warning callout background |
| `C_WARNING_LABEL` | `96700A`  | Warning callout label text / border |
| `C_SUCCESS_FILL`  | `F0FFF4`  | Success / stretch callout background |
| `C_SUCCESS_LABEL` | `007017`  | Success callout label text / border (same as C_JALAPENO) |

**Hard rules:**
- Never use `#0073AA` (old WP blue) — it is outdated. Always use `3858E9`.
- Never introduce off-palette colors without documenting them here first.

---

## 2. TYPOGRAPHY

### Facilitator Guide (docx)

| Element | Font | Size | Weight | Color |
|---------|------|------|--------|-------|
| Activity title | Arial | 22pt | Bold | `C_LICORICE` |
| "Facilitator Guide" subtitle | Arial | 13pt | Regular | `595959` |
| H1 section headings | Arial | 16pt | Bold | `C_BLUEBERRY` |
| H2 section headings | Arial | 13pt | Bold | `C_LICORICE` |
| Body text | Arial | 11pt | Regular | Default (black) |
| Step numbers (`1.  `) | Arial | 11pt | Regular | Default (inherits) |
| Callout label | Arial | 10pt | Bold | Matches `label_color` param |
| Callout body text | Arial | 10pt | Regular | Default |
| Code blocks | Courier New | 9–10pt | Regular | `C_LICORICE` |
| Source numbers | Arial | 10pt | Bold | Default |
| Source link text | Arial | 10pt | Regular | `C_BLUEBERRY` (hyperlink) |
| Source note text | Arial | 10pt | Regular | `595959` |
| Overview table labels | Arial | 10pt | Bold | `C_LICORICE` |
| Overview table values | Arial | 10pt | Regular | `C_LICORICE` |
| Italic intro lines (e.g., sources) | Arial | 10pt | Italic | `595959` |

### Slide Deck (pptx)

| Element | Font | Size | Weight | Color |
|---------|------|------|--------|-------|
| Title slide: activity title | Arial | 48–54pt | Bold | `WHITE` |
| Title slide: subtitle/category | Arial | 18pt | Regular | `WHITE` — ⚠️ NOT MUTED_DK; dark bg requires white |
| Title slide: breadcrumb ("WordPress Meetup Activity") | Arial | 14pt | Bold | `WHITE` |
| Title slide: URL (bottom-right) | Arial | 14pt | Regular | `WHITE` plain text — NOT a hyperlink; LibreOffice renders hyperlinks blue on dark bg |
| Slide title (each slide) | Arial | 28–32pt | Bold | `BLUE` |
| Section header title (section bar) | Arial | 24pt | Bold | `WHITE` on `BLUE` bar |
| Breadcrumb label (top-left, white slides) | Arial | 13pt | Regular | `MUTED` |
| Step instruction / numbered item text | Arial | 20pt | Regular | `BLACK` |
| Callout / tip text | Arial | 15pt | Regular | `BLACK` |
| Speaker notes | Arial | 14pt | Regular | (notes pane only) |
| Captions / labels | Arial | 14pt | Regular | `MUTED` |
| Duration badge text | Arial | 18pt | Bold | `WHITE` |
| **Body text minimum (slides)** | Arial | **14pt** | — | — |
| Line spacing (all body paragraphs) | — | **1.2× (120%)** | — | — |
| List item spacing | — | **0.65" top-to-top** | — | — |

**Two levels of muted text for slides:**
- `MUTED` (#757575) — captions and breadcrumbs on white/light backgrounds
- `MUTED_DK` (#AAAAAA) — subtitle/secondary text on dark backgrounds (title, debrief slides)

---

## 3. PAGE / SLIDE DIMENSIONS

### Facilitator Guide (docx)

```python
sec.page_width  = Emu(7772400)   # 8.5 inches (US Letter)
sec.page_height = Emu(10058400)  # 11 inches
sec.left_margin   = Inches(1.0)
sec.right_margin  = Inches(1.0)
sec.top_margin    = Inches(1.0)
sec.bottom_margin = Inches(1.0)
# Content width = 6.5 inches (9360 DXA)
```

### Slide Deck (pptx)

```python
prs = Presentation()
prs.slide_width  = Emu(12192000)   # 13.33 inches (16:9 widescreen)
prs.slide_height = Emu(6858000)    # 7.5 inches
# Standard margins: 0.55" (inches(0.55)) on all sides
```

---

## 4. FACILITATOR GUIDE — CANONICAL PYTHON HELPERS

Every build script must include and use these exact implementations. Copy them verbatim. Do not adapt or simplify.

### `add_hyperlink`

```python
def add_hyperlink(paragraph, text, url, size_pt=11, bold=False):
    part = paragraph.part
    r_id = part.relate_to(
        url,
        "http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink",
        is_external=True,
    )
    hl = OxmlElement("w:hyperlink")
    hl.set(qn("r:id"), r_id)
    run_el = OxmlElement("w:r")
    rPr = OxmlElement("w:rPr")
    fonts = OxmlElement("w:rFonts")
    fonts.set(qn("w:ascii"), "Arial"); fonts.set(qn("w:hAnsi"), "Arial")
    rPr.append(fonts)
    sz = OxmlElement("w:sz"); sz.set(qn("w:val"), str(size_pt * 2)); rPr.append(sz)
    color = OxmlElement("w:color"); color.set(qn("w:val"), C_BLUEBERRY); rPr.append(color)
    u = OxmlElement("w:u"); u.set(qn("w:val"), "single"); rPr.append(u)
    if bold:
        b = OxmlElement("w:b"); rPr.append(b)
    run_el.append(rPr)
    t = OxmlElement("w:t"); t.text = text
    if text and (text[0] == " " or text[-1] == " "):
        t.set("{http://www.w3.org/XML/1998/namespace}space", "preserve")
    run_el.append(t); hl.append(run_el)
    paragraph._p.append(hl)
    return hl
```

### `add_run`

```python
def add_run(paragraph, text, bold=False, italic=False, size=11, hex_color=None):
    run = paragraph.add_run(text)
    run.font.name = "Arial"; run.font.size = Pt(size)
    run.bold = bold; run.italic = italic
    if hex_color:
        r, g, b = int(hex_color[0:2], 16), int(hex_color[2:4], 16), int(hex_color[4:6], 16)
        run.font.color.rgb = RGBColor(r, g, b)
    return run
```

### `add_step` — CANONICAL (numbered activity steps)

```python
def add_step(doc, number, parts):
    p = doc.add_paragraph()
    p.paragraph_format.left_indent = Inches(0.35)
    p.paragraph_format.first_line_indent = Inches(-0.3)
    p.paragraph_format.space_before = Pt(2)
    p.paragraph_format.space_after = Pt(5)
    add_run(p, f"{number}.  ", size=11)
    for part in parts:
        if isinstance(part, str):
            add_run(p, part, size=11)
        elif isinstance(part, tuple):
            add_hyperlink(p, part[0], part[1], size_pt=11)
        elif isinstance(part, dict):
            add_run(p, part["text"], bold=part.get("bold", False),
                    italic=part.get("italic", False), size=11)
```

**`parts` format:** plain strings | `(text, url)` tuples for hyperlinks | `{"text": str, "bold": bool, "italic": bool}` dicts.

**NEVER:**
- `style="List Number"` or any other Word built-in list style
- bullet characters (`•`, `*`, `-`) for steps

### `add_bullet` — sub-bullet items inside a section

```python
def add_bullet(doc, parts, indent=0.3):
    p = doc.add_paragraph()
    p.paragraph_format.left_indent = Inches(indent + 0.2)
    p.paragraph_format.first_line_indent = Inches(-0.2)
    p.paragraph_format.space_before = Pt(2)
    p.paragraph_format.space_after = Pt(4)
    br = p.add_run("*  ")
    br.font.name = "Arial"; br.font.size = Pt(11)
    br.font.color.rgb = RGBColor(0x38, 0x58, 0xE9)
    for part in parts:
        if isinstance(part, tuple):
            add_hyperlink(p, part[0], part[1])
        elif isinstance(part, dict):
            add_run(p, part["text"], bold=part.get("bold", False), size=11)
        else:
            add_run(p, part, size=11)
    return p
```

Note: `*  ` is used (not `•`) and rendered in Blueberry. This is for sub-bullets within body content, not activity steps.

### `add_callout` — CANONICAL (facilitator tip / warning / success boxes)

```python
def add_callout(doc, label, lines, color=C_LBLUE, label_color=C_BLUEBERRY):
    tbl = doc.add_table(rows=1, cols=1)
    tbl.style = "Table Grid"
    cell = tbl.cell(0, 0)
    style_cell(cell, color, left_border_hex=label_color, left_border_sz=24)
    cell.width = Inches(6.5)
    p = cell.paragraphs[0]
    add_run(p, label + "  ", bold=True, size=10, hex_color=label_color)
    for i, line in enumerate(lines):
        if i == 0:
            add_run(p, line, size=10)
        else:
            p2 = cell.add_paragraph()
            add_run(p2, line, size=10)
            para_spacing(p2, before=6, after=20)  # before=6 adds visible gap between paragraphs
    para_spacing(p, after=20)
    doc.add_paragraph()
```

**Callout variants** (pass as `color` and `label_color` kwargs):

| Type | color | label_color |
|------|-------|-------------|
| Default / tip (blue) | `C_LBLUE` = `"EEF1FD"` | `C_BLUEBERRY` = `"3858E9"` |
| Warning (amber) | `"FFF8E1"` | `"96700A"` |
| Success / stretch (green) | `"F0FFF4"` | `"007017"` |

**NEVER:**
- Put the label on its own line (label is always inline with the first content line)
- Use bullet characters (`•`, `*`) inside callout lines
- Use a separate header paragraph above the callout cell content
- Cram multiple concepts into one long paragraph — each distinct idea is a separate `lines` entry so paragraphs are visually separated

### `add_heading` — CANONICAL

```python
def add_heading(doc, text, level=1):
    p = doc.add_paragraph()
    if level == 1:
        p.paragraph_format.space_before = Pt(18)
        p.paragraph_format.space_after = Pt(8)
        r = p.add_run(text)
        r.font.name = "Arial"; r.font.size = Pt(16)
        r.bold = True; r.font.color.rgb = RGBColor(0x38, 0x58, 0xE9)
    elif level == 2:
        p.paragraph_format.space_before = Pt(14)
        p.paragraph_format.space_after = Pt(6)
        r = p.add_run(text)
        r.font.name = "Arial"; r.font.size = Pt(13)
        r.bold = True; r.font.color.rgb = RGBColor(0x1E, 0x1E, 0x1E)
    return p
```

**NEVER** use `doc.add_heading(text, level=N)` (the python-docx built-in heading method) or `style="Heading 1"` — these rely on Word's default style cascade and produce inconsistent results across viewers. Always use the custom `add_heading` function above.

### `add_part_header` — section banner

```python
def add_part_header(doc, number, title, duration):
    tbl = doc.add_table(rows=1, cols=1)
    tbl.style = "Table Grid"
    cell = tbl.cell(0, 0)
    style_cell(cell, C_BLUEBERRY)
    cell.width = Inches(6.5)
    p = cell.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.LEFT
    p.paragraph_format.space_before = Pt(4)
    p.paragraph_format.space_after  = Pt(4)
    add_run(p, f"Part {number}: {title}", bold=True, size=13, hex_color=C_WHITE)
    add_run(p, f"   |   {duration}", size=11, hex_color="BDD3F8")
    doc.add_paragraph()
```

### `add_code_block`

```python
def add_code_block(doc, code_text):
    tbl = doc.add_table(rows=1, cols=1)
    tbl.style = "Table Grid"
    cell = tbl.cell(0, 0)
    style_cell(cell, "F0F0F0")
    cell.width = Inches(6.5)
    for line in code_text.split("\n"):
        p = cell.add_paragraph()
        run = p.add_run(line if line else " ")
        run.font.name = "Courier New"; run.font.size = Pt(9)
        run.font.color.rgb = RGBColor(0x1E, 0x1E, 0x1E)
        para_spacing(p, after=0)
    if cell.paragraphs and not cell.paragraphs[0].text.strip():
        cell._tc.remove(cell.paragraphs[0]._element)
    doc.add_paragraph()
```

### `add_sources` — CANONICAL (Sources section)

```python
def add_sources(doc):
    add_heading(doc, "Sources")

    note_p = doc.add_paragraph()
    add_run(note_p, "All URLs verified as of [Month Year]. Check before running the activity.",
            italic=True, size=10, hex_color="595959")
    note_p.paragraph_format.space_after = Pt(6)

    sources = [
        ("Source title", "https://example.com/", "One-sentence note."),
        # ...
    ]

    for i, (title_text, url, note_text) in enumerate(sources):
        p = doc.add_paragraph()
        p.paragraph_format.left_indent = Inches(0.3)
        p.paragraph_format.first_line_indent = Inches(-0.3)
        p.paragraph_format.space_before = Pt(2)
        p.paragraph_format.space_after = Pt(5)
        nr = p.add_run(f"{i+1}.  ")
        nr.font.name = "Arial"; nr.font.size = Pt(10); nr.bold = True
        add_hyperlink(p, title_text, url, size_pt=10)
        nn = p.add_run(f": {note_text}")
        nn.font.name = "Arial"; nn.font.size = Pt(10)
        nn.font.color.rgb = RGBColor(0x59, 0x59, 0x59)

    doc.add_paragraph()
```

**NEVER** use a table for sources. Always use this numbered inline list.
Update `[Month Year]` to the current month and year when writing the script.

### `add_divider`

```python
def add_divider(doc):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(10)
    p.paragraph_format.space_after = Pt(10)
    pPr = p._p.get_or_add_pPr()
    pBdr = OxmlElement("w:pBdr")
    bottom = OxmlElement("w:bottom")
    bottom.set(qn("w:val"), "single"); bottom.set(qn("w:sz"), "4")
    bottom.set(qn("w:space"), "1"); bottom.set(qn("w:color"), "CCCCCC")
    pBdr.append(bottom); pPr.append(pBdr)
```

### `style_cell` (shared table utility)

```python
def style_cell(cell, fill_hex, left_border_hex=None, left_border_sz=24):
    tc = cell._tc; tcPr = tc.get_or_add_tcPr()
    for el in tcPr.findall(qn("w:shd")): tcPr.remove(el)
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear"); shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), fill_hex); tcPr.append(shd)
    tcBorders = OxmlElement("w:tcBorders")
    for side in ("top", "left", "bottom", "right"):
        b = OxmlElement(f"w:{side}")
        if side == "left" and left_border_hex:
            b.set(qn("w:val"), "thick"); b.set(qn("w:sz"), str(left_border_sz))
            b.set(qn("w:color"), left_border_hex); b.set(qn("w:space"), "0")
        else:
            b.set(qn("w:val"), "none"); b.set(qn("w:sz"), "0"); b.set(qn("w:color"), "auto")
        tcBorders.append(b)
    tcPr.append(tcBorders)
    tcMar = OxmlElement("w:tcMar")
    for side, val in (("top", "80"), ("bottom", "80"), ("left", "160"), ("right", "160")):
        m = OxmlElement(f"w:{side}"); m.set(qn("w:w"), val); m.set(qn("w:type"), "dxa")
        tcMar.append(m)
    tcPr.append(tcMar)
```

### `set_table_width` (explicit DXA width)

```python
def set_table_width(table, width_dxa):
    tbl = table._tbl; tblPr = tbl.tblPr
    for el in tblPr.findall(qn("w:tblW")): tblPr.remove(el)
    tblW = OxmlElement("w:tblW")
    tblW.set(qn("w:w"), str(width_dxa)); tblW.set(qn("w:type"), "dxa")
    tblPr.append(tblW)
```

Full-width tables: `set_table_width(table, 9360)` (6.5" content area × 1440 DXA/inch).

---

## 5. SLIDE DECK — CANONICAL PYTHON HELPERS

### v4 Template (canonical for all NEW decks — 2026-05+)

**Reference implementation:** `build_content_creation_slides.py` is the canonical build script for all new slide decks.

All new decks import from `v3_slide_helpers.py` using:
```python
from v3_slide_helpers import *
from v3_slide_helpers import _run, _lnSpc, _anchor_ctr, _autonumber_pPr, _bullet_pPr, _cell_borders, num_step_para, _add_tab_stop
```

#### v4 Layout — Title slide (dark)
```
Background: BLACK (#1E1E1E)
- left_bar(slide)                          ← blue 0.32" bar, full height, x=0
- "WordPress Meetup Activity"              ← 14pt Bold WHITE, y=0.65", x=0.72"
- Activity title: 48–52pt Bold WHITE, y≈1.50", x=0.72"
- Subtitle: "N min · Level · Environment" ← 18pt WHITE (⚠️ NOT MUTED_DK — fails WCAG on black)
- URL plain text (no hyperlink)           ← 14pt WHITE, bottom-right; hyperlink_run() not used
  (LibreOffice renders hyperlinks blue on dark bg regardless of color setting)
```

#### v4 Layout — White slides with section bar (activity step slides)
```
top_bar(slide)                             ← thin blue line, full width, h=0.08"
supertitle: "Part N  ·  X minutes"        ← 12pt MUTED, y=0.10"
section_bar: full-width BLUE rect          ← h=0.68", y=0.38", 24pt Bold WHITE title
content_top = section_bar(...) return     ← ≈ 1.30" below slide top
Steps: num_steps(slide, steps, content_top)
tip_box: SPEAKER NOTES ONLY — renders nothing on slide
```

#### v4 Layout — White slides without section bar (agenda, tables, debrief, resources)
```
top_bar(slide)
title: slide_title_v4(slide, "Title")     ← 28pt Bold BLUE, y=0.20"
content_top = slide_title_v4(…) return   ← ≈ 0.95"
Content below (tables, rows, etc.)
```

#### v4 New helpers (all in v3_slide_helpers.py)

| Helper | Purpose |
|--------|---------|
| `top_bar(slide)` | Thin blue bar across top of all white slides |
| `left_bar(slide)` | Blue vertical bar for dark title slides |
| `slide_title_v4(slide, text)` | 28pt bold BLUE title; returns `content_top` |
| `section_bar(slide, title, supertitle)` | Full-width BLUE header bar; returns `content_top` |
| `num_step_para(p, n, body, size, spc_bef, slide)` | One numbered step paragraph (inline, no shapes) |
| `num_steps(slide, steps, top)` | All steps in one textframe; `body` accepts str or `[('bold','text'), ('link',url,'text'), ...]` |
| `tip_box(slide, text)` | **Speaker notes only** — stores facilitator tip via `_pending_tips`; renders NOTHING on slide. No `top` or `h` args. |
| `agenda_table(slide, rows, top)` | Lavender card rows: `(title, time_str)` list |
| `discussion_rows(slide, items, top)` | Debrief/discussion lavender rows with **bold** (never italic) BLUE number |
| `data_table(slide, headers, rows, top, col_widths, header_col)` | Blue header + alternating rows; `header_col=True` for comparison tables |

#### v3 helpers (still used by the 10 existing decks — do not change)

**Reference implementation:** `build_managing_wp_with_ai_slides.py` (v3, 2026-05) is the canonical reference for the 10 existing decks. Do not migrate them.

---

### v3 Constants block (unchanged)

### Constants block

```python
from lxml import etree
from pptx import Presentation
from pptx.util import Emu, Pt
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN
from pptx.oxml.ns import qn

W = Emu(12192000)   # 13.33" slide width (16:9)
H = Emu(6858000)    # 7.5"  slide height

BLUE      = RGBColor(0x38, 0x58, 0xE9)   # primary accent
BLUE_TINT = RGBColor(0xEE, 0xF1, 0xFD)   # facilitator tip bg
CAUTION   = RGBColor(0x96, 0x70, 0x0A)   # note/important accent bar
CAUTION_T = RGBColor(0xFF, 0xF8, 0xE1)   # note/important bg
BLACK     = RGBColor(0x1E, 0x1E, 0x1E)   # body text + dark bg
MUTED     = RGBColor(0x75, 0x75, 0x75)   # captions on light bg
MUTED_DK  = RGBColor(0xAA, 0xAA, 0xAA)  # captions/subtitles on dark bg
WHITE     = RGBColor(0xFF, 0xFF, 0xFF)
LGREY     = RGBColor(0xF0, 0xF0, 0xF0)   # code bg, light card bg

def inches(x): return Emu(int(x * 914400))
```

### Core shape/text helpers

```python
def set_bg(slide, color):
    fill = slide.background.fill; fill.solid(); fill.fore_color.rgb = color

def add_rect(slide, left, top, width, height, color, line=False):
    shape = slide.shapes.add_shape(1, left, top, width, height)
    shape.fill.solid(); shape.fill.fore_color.rgb = color
    if not line: shape.line.fill.background()
    return shape

def txb(slide, left, top, width, height):
    """Zero-margin text box."""
    box = slide.shapes.add_textbox(left, top, width, height)
    tf = box.text_frame; tf.word_wrap = True
    tf.margin_left = tf.margin_right = tf.margin_top = tf.margin_bottom = Emu(0)
    return tf, box

def _run(para, text, size=16, bold=False, italic=False, color=None):
    run = para.add_run(); run.text = text
    run.font.name = 'Arial'; run.font.size = Pt(size)
    run.font.bold = bold; run.font.italic = italic
    if color: run.font.color.rgb = color
    return run

def first_para(tf, text='', size=16, bold=False, italic=False,
               color=None, align=PP_ALIGN.LEFT, lspc=120):
    p = tf.paragraphs[0]; p.alignment = align
    _lnSpc(p, lspc)
    run = p.add_run(); run.text = text
    run.font.name = 'Arial'; run.font.size = Pt(size)
    run.font.bold = bold; run.font.italic = italic
    if color: run.font.color.rgb = color
    return p

def add_para(tf, text='', size=16, bold=False, color=None,
             align=PP_ALIGN.LEFT, lspc=120, spc_bef=None):
    p = tf.add_paragraph(); p.alignment = align
    if spc_bef is not None: p.space_before = Pt(spc_bef)
    _lnSpc(p, lspc)
    run = p.add_run(); run.text = text
    run.font.name = 'Arial'; run.font.size = Pt(size)
    run.font.bold = bold
    if color: run.font.color.rgb = color
    return p
```

### XML helpers for advanced formatting

```python
def _lnSpc(para, pct=120):
    """Set paragraph line spacing as percentage (120 = 1.2×)."""
    pPr = para._p.get_or_add_pPr()
    for el in pPr.findall(qn('a:lnSpc')): pPr.remove(el)
    lnSpc = etree.SubElement(pPr, qn('a:lnSpc'))
    etree.SubElement(lnSpc, qn('a:spcPct')).set('val', str(pct * 1000))

def _anchor_ctr(shape_or_tf):
    """Vertically center text in a shape/textframe via bodyPr anchor='ctr'."""
    if shape_or_tf is None: return
    txBody = shape_or_tf.text_frame._txBody if hasattr(shape_or_tf, 'text_frame') \
             else shape_or_tf._txBody
    bodyPr = txBody.find(qn('a:bodyPr'))
    if bodyPr is not None: bodyPr.set('anchor', 'ctr')

def _autonumber_pPr(para, num, mar_emu=274638):
    """Blue buAutoNum with hanging indent. num=1 for first item, higher for continuations."""
    pPr = para._p.get_or_add_pPr()
    pPr.set('marL', str(mar_emu)); pPr.set('indent', str(-mar_emu))
    for tag in ['a:buClr','a:buClrTx','a:buFont','a:buFontTx',
                'a:buChar','a:buAutoNum','a:buNone']:
        for el in pPr.findall(qn(tag)): pPr.remove(el)
    clr = etree.SubElement(pPr, qn('a:buClr'))
    etree.SubElement(clr, qn('a:srgbClr')).set('val', '3858E9')
    fnt = etree.SubElement(pPr, qn('a:buFont')); fnt.set('typeface', 'Arial')
    auto = etree.SubElement(pPr, qn('a:buAutoNum')); auto.set('type', 'arabicPeriod')
    if num > 1: auto.set('startAt', str(num))  # each textbox resets counter; use startAt

def _bullet_pPr(para, mar_emu=274638):
    """buChar bullet (•) with hanging indent."""
    pPr = para._p.get_or_add_pPr()
    pPr.set('marL', str(mar_emu)); pPr.set('indent', str(-mar_emu))
    for tag in ['a:buClr','a:buClrTx','a:buFont','a:buFontTx',
                'a:buChar','a:buAutoNum','a:buNone']:
        for el in pPr.findall(qn(tag)): pPr.remove(el)
    fnt = etree.SubElement(pPr, qn('a:buFont')); fnt.set('typeface', 'Arial')
    char = etree.SubElement(pPr, qn('a:buChar')); char.set('char', '•')
```

### Navigation and layout helpers

```python
def breadcrumb(slide, text, dark=False):
    """Small gray path label at top-left. Replaces old slide_label bar."""
    tf, _ = txb(slide, inches(0.55), inches(0.08), inches(10.0), inches(0.30))
    p = tf.paragraphs[0]
    _run(p, text, size=13, color=MUTED_DK if dark else MUTED)

def slide_title(slide, text, dark=False):
    """Standard content slide title — 28pt Bold BLUE, left-aligned."""
    tf, _ = txb(slide, inches(0.55), inches(0.38), inches(12.0), inches(0.70))
    first_para(tf, text, size=28, bold=True, color=WHITE if dark else BLUE, lspc=110)

def section_header(slide, badge_text, title_text):
    """Small BLUE badge + bold BLUE title — use for Part N/Step N header slides."""
    badge_w = inches(0.62); badge_h = inches(0.50)
    badge = add_rect(slide, inches(0.55), inches(0.55), badge_w, badge_h, BLUE)
    btf = badge.text_frame
    btf.margin_top = btf.margin_bottom = btf.margin_left = btf.margin_right = Emu(0)
    bp = btf.paragraphs[0]; bp.alignment = PP_ALIGN.CENTER
    _lnSpc(bp, 120); _anchor_ctr(badge)
    br = bp.add_run(); br.text = badge_text
    br.font.name = 'Arial'; br.font.size = Pt(20); br.font.bold = True; br.font.color.rgb = WHITE
    tf2, _ = txb(slide, inches(0.55) + badge_w + inches(0.13), inches(0.55),
                 W - inches(0.55) - badge_w - inches(0.13) - inches(0.55), badge_h)
    first_para(tf2, title_text, size=24, bold=True, color=BLUE, lspc=110)
```

### List item helpers (returns next `top` value)

```python
def num_item(slide, n, text, top, left=None, width=None, size=20, h=None):
    """Numbered list item using buAutoNum. Returns top + 0.65" for next item."""
    if left is None: left = inches(0.55)
    if width is None: width = W - left - inches(0.55)
    if h is None: h = inches(0.55)
    tf, _ = txb(slide, left, top, width, h)
    p = tf.paragraphs[0]; _lnSpc(p, 120); _autonumber_pPr(p, n)
    _run(p, text, size=size, color=BLACK)
    return top + inches(0.65)

def bul_item(slide, text, top, left=None, width=None, size=20, bold=False, h=None):
    """Bullet list item using buChar. Returns top + 0.65" for next item."""
    if left is None: left = inches(0.55)
    if width is None: width = W - left - inches(0.55)
    if h is None: h = inches(0.55)
    tf, _ = txb(slide, left, top, width, h)
    p = tf.paragraphs[0]; _lnSpc(p, 120); _bullet_pPr(p)
    _run(p, text, size=size, bold=bold, color=BLACK)
    return top + inches(0.65)
```

**Key rule:** `num_item` / `bul_item` use **separate textboxes per item**. The 0.65" top-to-top interval keeps spacing consistent regardless of text wrapping.

### Callout helpers

**Hard rule: `tip_callout()` is NEVER rendered on slides.** Facilitator tips are for the presenter only — they must not appear on the projected slide. `tip_callout()` stores its text and `set_notes()` automatically appends it to the slide's speaker notes prefixed with 💡. Callers do not need to do anything special — just call `tip_callout()` as normal and it will end up in the notes.

```python
# tip_callout — stores tip for speaker notes, renders NOTHING on slide
tip_callout(slide, "Pause here and ask the room ...", top)
# → top is returned unchanged (no space consumed)
# → set_notes() will append: "💡 Facilitator tip: Pause here and ask the room ..."

# note_callout — rendered on slide (participant-facing amber box)
note_callout(slide, "Participants on WP.com Simple plan ...", top)
# → renders visible amber callout; top advances by 0.75"

# success_callout — rendered on slide (green stretch-goal box)
success_callout(slide, "Stretch: also test with a screen reader", top)
# → renders visible green callout; top advances by 0.75"
```

**Summary of callout visibility:**

| Helper | Rendered on slide? | Appears in notes? |
|---|---|---|
| `tip_callout()` | ❌ Never | ✅ Always (via `set_notes()`) |
| `note_callout()` | ✅ Yes — amber | — |
| `success_callout()` | ✅ Yes — green | — |

**Vertical centering (note/success boxes):** Use `_anchor_ctr(tf)` — sets `<a:bodyPr anchor="ctr">` directly via XML. The `python-pptx` API does not expose this property; it requires XML manipulation. **Never use top/bottom margin fiddling to fake centering** — the result is uneven when text wraps.

### Hyperlink helper (text-frame runs)

```python
def hyperlink_run(slide, para, text, url, size=16, color=None, bold=False):
    """Hyperlinked text run in a text frame paragraph.
    IMPORTANT: run.hyperlink.address does NOT work for text-frame runs.
    Must use slide.part.relate_to() + XML a:hlinkClick."""
    rId = slide.part.relate_to(
        url,
        'http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink',
        is_external=True
    )
    run = para.add_run(); run.text = text
    run.font.name = 'Arial'; run.font.size = Pt(size)
    run.font.bold = bold
    if color: run.font.color.rgb = color
    rPr = run._r.get_or_add_rPr()
    hl = etree.SubElement(rPr, qn('a:hlinkClick'))
    hl.set(qn('r:id'), rId)
```

**NEVER use `run.hyperlink.address` for text-frame runs** — that API is shape-level only and silently fails for textbox runs. Always use `hyperlink_run()` above.

---

## 6. SLIDE LAYOUT PATTERNS

### Slide backgrounds

| Slide type | Background |
|------------|-----------|
| Title slide | `BLACK` (`#1E1E1E`) |
| Debrief slide | `BLACK` (`#1E1E1E`) |
| All other slides | `WHITE` (`#FFFFFF`) |

**Never use cream, beige, or off-white defaults** — background is always pure `#FFFFFF` or `#1E1E1E`.

### Text color on dark-background slides

- **All text**: `WHITE` — this is the only safe color on a black (#1E1E1E) background
- `MUTED_DK` (#AAAAAA) **fails WCAG AA on black** and must never be used on dark slides
- `MUTED` (#757575) also fails — never use on dark backgrounds
- Hyperlinks on dark slides: use `_run(p, text, color=WHITE)` — NOT `hyperlink_run()`. LibreOffice overrides hyperlink run colors to its own theme blue regardless of explicit XML color settings.

### Standard margins (slides)

All text boxes and content elements: `inches(0.55)` from left/right edges, `inches(0.40)` from top/bottom edges.

### Title slide layout (v4)

```
Background: BLACK (#1E1E1E)
- left_bar(slide)                                    — blue vertical bar, x=0, full height
- "WordPress Meetup Activity": 14pt Bold WHITE        — top-left breadcrumb
- Activity title: 48–52pt Bold WHITE, y≈1.50"
- Subtitle "N min · Level · Environment": 18pt WHITE  — ⚠️ WHITE not MUTED_DK
- URL plain text: 14pt WHITE, bottom-right            — _run() not hyperlink_run()
```

### Part/section header slide layout

```
Background: WHITE
- breadcrumb(slide, 'Part N — Section Name') — top-left, 13pt MUTED
- section_header(slide, 'NA', 'Full step title') — BLUE badge + 24pt Bold BLUE title
  badge at y=0.55", h=0.50", w=0.62"
- Body content top: inches(1.42)
```

**NEVER** use a large decorative number + `slide_title()` at the same y — they overlap.
**NEVER** use `part_slide_header()` (old v2 helper, removed in v3).

### Content slide layout

```
Background: WHITE
- breadcrumb(slide, '...') — top-left
- slide_title(slide, 'Title') — 28pt Bold BLUE at y≈0.38"
- Body content top: inches(1.35)
```

### Numbered list slides

Use `num_item()` helper — **one textbox per item**, 0.65" top-to-top interval:

```python
top = inches(1.42)
top = num_item(slide, 1, 'First step text', top)
top = num_item(slide, 2, 'Second step text', top)
top = num_item(slide, 3, 'Third step text', top)
# Add note_callout or success_callout at top + 0.40" clearance
# tip_callout goes here too if needed — it won't render on slide, just in notes
```

**Never** use colored badge rectangles next to numbered items for normal lists — that pattern is reserved for UI showcase elements (e.g., showing WordPress tool names as pills). Use `buAutoNum` via `num_item()`.

### Callout placement

- Always ≥ `inches(0.40)` clearance above a `note_callout` / `success_callout` from the last content element.
- Always ≥ `inches(0.25)` clearance below a callout to the slide edge.
- `tip_callout()` consumes zero space and needs no clearance — it only writes to speaker notes.
- Use `note_callout()` for participant-facing warnings/important info (amber, rendered on slide).
- Use `success_callout()` for stretch goals (green, rendered on slide).
- Use `tip_callout()` for facilitator-only guidance — **never rendered on slide**.

### Q&A / Common Questions slide layout

Use **two separate textboxes per pair** (one for Q, one for A), with explicit heights that accommodate wrapped text:

```python
top = inches(1.35)
for q, a in qas:
    tf_q, _ = txb(slide, inches(0.55), top, inches(11.8), inches(0.42))
    first_para(tf_q, q, size=18, bold=True, color=BLUE, lspc=120)
    top += inches(0.47)
    tf_a, _ = txb(slide, inches(0.55), top, inches(11.8), inches(0.80))
    first_para(tf_a, a, size=16, color=BLACK, lspc=120)
    top += inches(0.93)   # 0.80" box + 0.13" gap before next Q
```

Answer box height of `inches(0.80)` accommodates up to 3 wrapped lines at 16pt/1.2×. The 0.13" gap between pairs is uniform.

### Debrief slide layout

```
Background: BLACK (#1E1E1E)
- breadcrumb(slide, 'Debrief', dark=True) — top-left, 13pt MUTED_DK
- Primary statement: Arial 44–48pt Bold WHITE, centered
- Discussion question: Arial 24–26pt WHITE, centered
- Sub-questions: Arial 18pt MUTED_DK, centered
```

---

## 7. DOCUMENT STRUCTURE ORDER

Every facilitator guide must follow this section order without exception:

1. Title block (see canonical pattern below)
2. Overview section (see canonical pattern below)
3. Learning Objectives
4. What Participants Need (prerequisites + environment)
5. Facilitator Setup Notes
6. Activity Parts (Part 1 … Part N, each with Background + What participants do)
7. Debrief (5 minutes)
8. Sources

### Canonical title block pattern

Every facilitator guide title block must follow this exact structure (in this order):

```
[Blue banner: "Hands-On WordPress Meetup Activity", white bold 10pt, blueberry fill]
[Blank paragraph]
[Activity title: 22pt Bold Licorice, no line breaks in the title]
["Facilitator Guide" subtitle: 13pt Regular #505050]
[add_divider()]
```

Python implementation:
```python
def add_title_block(doc):
    tbl = doc.add_table(rows=1, cols=1)
    tbl.style = "Table Grid"
    cell = tbl.cell(0, 0)
    style_cell(cell, C_BLUEBERRY)
    cell.width = Inches(6.5)
    p = cell.paragraphs[0]
    p.paragraph_format.space_before = Pt(4)
    p.paragraph_format.space_after  = Pt(4)
    add_run(p, "Hands-On WordPress Meetup Activity", bold=True, size=10, hex_color=C_WHITE)

    doc.add_paragraph()

    title = doc.add_paragraph()
    add_run(title, "Your Activity Title Here", bold=True, size=22, hex_color=C_LICORICE)
    title.paragraph_format.space_before = Pt(0)
    title.paragraph_format.space_after  = Pt(4)

    sub = doc.add_paragraph()
    add_run(sub, "Facilitator Guide", size=13, hex_color="505050")
    sub.paragraph_format.space_after = Pt(2)

    add_divider(doc)
```

**Hard rules:**
- Title is a single line (no `\n` line breaks inside the title string)
- Title is always 22pt Bold Licorice — never 26pt, never a different color
- "Facilitator Guide" subtitle is always present, always 13pt #505050
- `add_divider()` always closes the title block
- Do NOT place a 4-column horizontal meta table here — that goes in `add_overview()` as a 2-column vertical table

### Canonical overview section pattern

Every facilitator guide overview section must follow this exact structure:

```
[H1: "Overview"]
[Description paragraph — 1–2 sentences, 11pt]
[2-col 6-row table: rows = Topic / Duration / Audience / Prerequisite / Environment / Materials]
[Blank paragraph]
[add_warning_callout()]
[add_divider()]
```

Python implementation:
```python
def add_overview(doc):
    doc.add_heading("Overview", level=1)
    p = doc.add_paragraph()
    add_run(p, "One or two sentences describing the activity.", size=11)
    p.paragraph_format.space_after = Pt(8)

    tbl = doc.add_table(rows=6, cols=2)
    tbl.style = "Table Grid"
    set_table_width(tbl)
    set_col_widths(tbl, [1.5, 5.0])
    rows_data = [
        ("Topic",        "Short topic name"),
        ("Duration",     "60 minutes"),
        ("Audience",     "Beginner–Intermediate (describe the audience)"),
        ("Prerequisite", "A modern browser; no WordPress account required"),
        ("Environment",  "WordPress Playground — playground.wordpress.net"),
        ("Materials",    "This facilitator guide, slide deck, participants bring their own device"),
    ]
    for i, (label, value) in enumerate(rows_data):
        fill = "F0F0F0" if i % 2 == 0 else C_WHITE
        lc = tbl.cell(i, 0)
        rc = tbl.cell(i, 1)
        style_cell(lc, fill)
        style_cell(rc, C_WHITE)
        pl = lc.paragraphs[0]
        pr = rc.paragraphs[0]
        pl.paragraph_format.space_before = Pt(2)
        pl.paragraph_format.space_after  = Pt(2)
        pr.paragraph_format.space_before = Pt(2)
        pr.paragraph_format.space_after  = Pt(2)
        add_run(pl, label, bold=True, size=10, hex_color=C_LICORICE)
        add_run(pr, value, size=10, hex_color=C_LICORICE)

    doc.add_paragraph()
    add_warning_callout(doc)
    add_divider(doc)
```

**Hard rules:**
- Heading is always `"Overview"` — never `"Activity Overview"`, never a different word
- Table is always 2 columns (1.5" label / 5.0" value), 6 rows, alternating F0F0F0 / white fills
- Row labels are always: Topic, Duration, Audience, Prerequisite, Environment, Materials — in that order
- `add_warning_callout()` always follows the table
- `add_divider()` always closes the overview section
- Do NOT include Prerequisites or Materials as bullet-list paragraphs after the overview — those belong in the table only

Every slide deck must follow this slide order:

1. Title slide (dark)
2. Learning objectives / "What you'll be able to do"
3. What you need (environment + URL)
4. Activity overview (part structure with times)
5. Activity step slides (one major step per slide)
6. [Optional] Common questions / troubleshooting
7. Debrief (dark)
8. Next steps / resources

---

## 8. FILE NAMING AND FOLDER STRUCTURE

```
Hands-On WordPress Meetup Activity Library/
  [Topic Name]/
    [Topic Name] — Facilitator Guide.docx
    [Topic Name] — Slides.pptx
```

**Topic Name** must match the canonical name from the Approved Topic List exactly. Use em dashes (`—`) as the separator between topic name and file type (this is part of the filename, not body copy — the "no em dashes in body copy" rule does not apply here).

Build scripts:
```
build_[topic_slug]_facilitator_guide.py
build_[topic_slug]_slides.py
```

---

## 9. HARD "NEVER" RULES

These have caused real consistency problems in the past. Do not repeat them.

**Slides (v4 — new decks):**

| ❌ Never | ✅ Instead |
|----------|-----------|
| Floating blue badge shapes with white numbers for steps | `num_step_para()` / `num_steps()` — inline numbered paragraphs |
| Any visible facilitator note box on a slide (gray, labeled "Facilitator note:", etc.) | `tip_box(slide, text)` or `tip_callout()` — stores in speaker notes only, renders **nothing** on the slide |
| Using `note_callout()` for facilitator-only guidance | `note_callout()` is for **participant-facing** notes visible on slide (amber). Facilitator guidance always goes in speaker notes via `tip_box()` or `tip_callout()` |
| A duration badge box in the corner of the title slide | Inline subtitle text: "N min · Level · Environment" in MUTED_DK |
| `section_header()` with badge for new decks | `section_bar(slide, title, supertitle)` — full-width blue bar |
| Multiple textboxes for one step list | One textframe, one paragraph per step via `num_steps()` |
| `TIP_Y` constant or any fixed y-coordinate for tip boxes | `tip_box()` takes no positional args — it writes to speaker notes and returns `top` unchanged |
| Italic numbers in `discussion_rows()` or any row numbers | Numbers are always bold, never italic — `_run(p, n, bold=True, color=BLUE)` |
| Inline hyperlinks at the end of a line where the URL label can orphan (split across lines by the PDF renderer) | Place hyperlinks mid-sentence or in a parenthetical group `(Link1, Link2, or Link3)` so wrapping distributes cleanly; never end a step with a lone linked word |

**Slides (both v3 and v4):**

| ❌ Never | ✅ Instead |
|----------|-----------|
| Blue (`BLUE`), grey (`MUTED_DK`), or any non-white color on a dark/black background | All text on dark title slides must be `WHITE`. `MUTED_DK` (#AAAAAA) fails WCAG AA on black — it is only for secondary text on projector-white backgrounds. Hyperlinks on dark slides use `_run()` with `color=WHITE` (not `hyperlink_run()`) — LibreOffice overrides hyperlink run colors to blue regardless of explicit XML. |
| A "Facilitator Prep" or "Before you arrive" slide in the deck | Move all prep content to Slide 1's speaker notes (`set_notes()`) |
| Custom inline resource lists (label + `—` + hyperlink) on end slides | `resources_table(slide, y_start, [(label, url), ...])` two-column table |
| Accent lines / rules under slide titles | Use whitespace or background color instead |
| Full-width decorative colored bars/stripes | Prohibited — reads as AI-generated slop |
| Cream/beige background (#FAF0E6 etc.) | Pure `WHITE` (#FFFFFF) or `BLACK` (#1E1E1E) only |
| `MUTED` (#757575) on dark background slides | `MUTED_DK` (#AAAAAA) — higher contrast for projectors |
| `run.hyperlink.address = url` in textbox runs | `hyperlink_run(slide, para, text, url)` — XML `a:hlinkClick` |
| Text overflow / clipping at box bottom | Size boxes generously; verify in QA |
| Body text < 14pt | 14pt minimum for all body text in slides |
| Line spacing other than 1.2× on body text | `_lnSpc(para, 120)` on every paragraph |
| `#0073AA` (old WP blue) | `#3858E9` (BLUE / WP Blueberry) |
| Centered body text | Left-align body — only slide titles and centered decorative text centered |

**Build scripts (all):**

| ❌ Never | ✅ Instead |
|----------|-----------|
| Curly/smart quotes in Python string literals — `'`, `'`, `"`, `"` (Unicode U+2018/2019/201C/201D) | Straight ASCII quotes only: `'` and `"`. The Edit tool sometimes inserts curly quotes, which cause `SyntaxError: invalid character` at runtime. If a build script fails with a syntax error on a string, run a binary replace: `content.replace(b'\xe2\x80\x98', b"'").replace(b'\xe2\x80\x99', b"'")` etc. |

**Facilitator guides (docx):**

| ❌ Never | ✅ Instead |
|----------|-----------|
| `style="List Number"` for steps | Manual `f"{number}.  "` with indent |
| Bullet char `•` or `*` for steps | Manual numbered prefix only |
| 4-column horizontal meta table in title block | 2-column 6-row overview table in `add_overview()` |
| `"Activity Overview"` as H1 heading | `"Overview"` exactly |
| Title with `\n` line break | Single-line title at 22pt Bold Licorice |
| Missing "Facilitator Guide" subtitle | Always include 13pt #505050 subtitle under title |
| Table for the Sources section | Numbered inline list (`add_sources` pattern) |
| Label on its own line in a callout | Label inline with first content line |
| Bullet chars in callout lines | Separate plain paragraphs (no bullets) |
| `WidthType.PERCENTAGE` for tables | `WidthType.DXA` / explicit DXA values |
| Tables as visual dividers | `add_divider()` (paragraph bottom border) |
| `Inter` font | Arial (Inter not reliably available in docx viewers) |

---

## 10. WORDPRESS UI TERMINOLOGY

Use the exact labels that appear in the WordPress admin UI. Several common actions are frequently mis-stated — memorize these:

| ❌ Never write | ✅ Always write | Where it appears |
|----------------|----------------|-----------------|
| "Add New Post" | "Add Post" | Posts menu |
| "Add New Page" | "Add Page" | Pages menu |
| "Add New Plugin" | "Add Plugin" | Plugins menu |
| "Add New Category" | "Add Category" | Categories panel in Post settings sidebar |

**Rule:** WordPress labels these actions with a simple noun ("Add Post", "Add Category"), not "Add New + noun". Do not add "New" to any of these action labels in guide steps, callouts, or slide instructions.

**Example (correct):**
> "In the left sidebar, go to **Posts** and click **Add Post**."

**Example (wrong):**
> "In the left sidebar, go to **Posts** and click **Add New Post**."

This applies equally to facilitator guides and slide decks.

---

---

## 11. CONTENT ACCURACY RULES

### Never assume UI steps — always verify

**Rule:** Do not write UI steps based on assumption or memory. Every step instruction (button label, menu path, field name) must be verified against:
1. The official WordPress documentation at wordpress.org/documentation/
2. The WordPress release notes / field guide for the version being targeted
3. Direct testing in WordPress Playground before publication

Common past errors caused by assumption (all of these have been reported and corrected):
- Writing "Add New Post" when the button says "Add Post"
- Writing "Add New Category" when the button says "Add Category"
- Writing "Add New Plugin" when the button says "Add Plugin"
- Describing a "Insert from URL" option in the Gallery block (it does not exist — Gallery uses Upload or Media Library only)
- Describing a "Insert from URL" tab in the Media Library modal for featured images (it does not exist)
- Using placeholder image URLs (picsum.photos) in activity steps

**When in doubt, check the WordPress documentation first and verify in Playground before writing.**

### Browser prerequisite wording

Always write: **"A modern browser with the latest update installed (Chrome or Firefox recommended)"**

Never write just "A modern browser" — the "with the latest update installed" qualifier ensures participants don't encounter issues with outdated browser versions.

### No placeholder image URLs

Never use `picsum.photos` or similar placeholder image services in activity steps. Instead:
- Direct participants to **Openverse** (openverse.org) for CC-licensed images
- Direct participants to **Pexels** (pexels.com) for free stock photos
- Note **Unsplash** (unsplash.com) as a third option

In the Facilitator Setup Notes, always include a row telling the facilitator to open tabs to openverse.org and pexels.com before the session.

### WordPress editor toolbars — two distinct toolbars

WordPress has two separate toolbars. Introduce this distinction early in any activity that uses the block editor:

- **Editor toolbar**: the horizontal bar running across the very top of the screen. Contains the block inserter (➕), Document Overview (outline icon), Undo/Redo, the post title area, the View button (preview), Settings (gear icon), and the Save/Publish button. Always refer to this as the "editor toolbar".
- **Block toolbar**: the smaller floating toolbar that appears directly above whichever block is currently selected. Contains block-specific controls (alignment, bold/italic, block type switcher, etc.). Always refer to this as the "block toolbar".

Never say "the toolbar" without qualifying which one.

### Gallery block: no "Insert from URL"

The WordPress Gallery block does **not** have an "Insert from URL" option. Gallery images must be added via:
- **Upload** — upload image files from the participant's computer
- **Media Library** — select from images already uploaded to the site

For any activity step involving the Gallery block, instruct participants to download images first (from Openverse or Pexels), then use the Upload option in the Gallery block.

---

## 12. SLIDE WRITING STYLE

These rules describe the voice, structure, and phrasing for slide content. All three slide types appear in every activity deck and must be written consistently.

---

### "What We Will Cover Today" slide (Agenda)

**Purpose:** Give participants a mental map of the session before it starts.

**Format:** `agenda_table()` rows. Each row = one part + time. Final row = Debrief + 5 min.

**Writing rules:**
- Part titles follow the pattern: `Part N — [Verb phrase describing the outcome]`  
  e.g., "Part 1 — The Block Editor: Building Your First Post"
- Part rows are **bold**, non-part rows (Debrief) are **regular weight**
- Times are short: "15 min", "10 min", "5 min" — not "15 minutes"
- No explanatory sentences — title only

---

### Explainer / concept slides (comparison tables, quick reference)

**Purpose:** Give participants just enough conceptual context to make the hands-on steps meaningful. Not a lecture — a reference card.

**Format:** `data_table()` with blue header row and alternating lavender rows. `header_col=True` for 3-column comparison tables.

**Writing rules:**
- Row labels (first column of comparison tables): concise noun phrases, title-case — "Appear in blog feed?", "Hierarchical?"
- Cell values: short, factual, no full sentences unless a sentence is clearly needed
- Use em dash (—) for brief explanations: "Yes — sorted by date"
- Quoted examples use curly quotes: "5 Tips for Faster WordPress Sites"
- No bullet points inside cells

---

### Activity step slides (section bar + numbered steps + tip)

**Purpose:** Guide participants through a hands-on task step by step. Self-explanatory — participants should be able to follow the slide without needing to hear the facilitator.

**Format:** `section_bar()` + `num_steps()` + `tip_box()`

**Writing rules for step text:**

1. **Imperative voice.** Every step begins with a verb. Never "You should click" — always "Click".

2. **Bold UI element names.** Anything the participant needs to find or click in the WordPress interface: `('bold', 'Posts > Add Post')`, `('bold', 'Featured Image')`, `('bold', 'Update')`. This includes: menu items, button labels, block names, sidebar panel names, keyboard shortcuts.

3. **Use → for sequential navigation** within a single step.  
   e.g., "Settings sidebar → **Featured Image** → Set Featured Image → Upload Files"

4. **Hyperlink URLs inline** where participants need to navigate to a URL.  
   e.g., step 1 of an activity linking directly to `playground.wordpress.net`

5. **Include keyboard shortcuts** where relevant: "Undo with Ctrl/Cmd+Z"

6. **Parenthetical location hints** for hard-to-find UI elements.  
   e.g., "(top-left of the editor toolbar)", "(gear icon)", "(in Summary panel)"

7. **Never exceed 6 steps per slide.** If an activity part needs more than 6 steps, split it into a second slide or consolidate closely related micro-steps.

8. **Step density:** Each step should represent a discrete, observable action — something the participant can do and verify. Avoid combining multiple unrelated actions in one step.

**Writing rules for `tip_box` text:**

- Write for the **facilitator**, not the participant — this is context and backstory
- Explain *why* something works the way it does, not just what to do
- Surface common participant confusion points: "Gallery block: Upload only (no 'Insert from URL')"
- Include version-specific behavior when relevant: "WP 7.0: patterns default to content-only mode"
- Keep to 1–3 sentences that fit in the gray box at 12pt
- Tone: matter-of-fact, not advisory ("Alt text is essential for accessibility and SEO" — not "Remember to explain why alt text matters")

**Writing rules for `section_bar` supertitle:**

Always formatted as: `"Part N  ·  X minutes"` — two spaces on each side of the middle dot, number matches the agenda.

---

### Debrief slide (discussion rows)

**Purpose:** Close the session with reflection questions that connect the hands-on work to participants' real sites.

**Format:** `discussion_rows()` — lavender cards with italic BLUE number, black question text.

**Writing rules:**
- 3 questions per debrief slide
- Each question asks participants to apply today's learning to their own context ("your site", "after today")
- Question 1: distinguishes two concepts introduced today (post vs page, etc.)
- Question 2: personal commitment — "What will you change?"
- Question 3: connects to a real past pain point — "Before today, what did you do when...?"
- Questions are complete sentences ending with a question mark
- Tone: conversational, not academic

---

## 13. SPACING QUICK REFERENCE

### Spacing Guide Tokens (pptx)

All spacing values in slide scripts must come from this scale. Every position and size must snap to a **0.05" grid** (multiples of `inches(0.05)` = 45720 EMU).

| Token | Value | Use for |
|-------|-------|---------|
| `space-xs` | `inches(0.05)` | Internal padding, fine adjustments |
| `space-sm` | `inches(0.10)` | Tight heading-to-body gap (heading directly above its immediate body item) |
| `space-md` | `inches(0.15)` | **Minimum gap between any two elements** (hard floor) |
| `space-lg` | `inches(0.25)` | Standard gap between sections, before/after code blocks |
| `space-xl` | `inches(0.40)` | Top/bottom safe-zone margins |
| `space-2xl` | `inches(0.50)` | Left/right safe-zone margins |

> **Note on canvas:** This spacing guide was authored for 10"×7.5" (4:3) slides. Our deck uses 13.33"×7.5" (16:9). All token values are absolute and apply to both formats. Do not adjust token values for the wider canvas.

### Body Text Minimum — 14pt

All body text in slides must be ≥ 14pt. No exemptions — even code blocks and captions must be ≥ 14pt. Line spacing: **1.2× (120%)** on all body paragraphs via `_lnSpc(para, 120)`.

### List Item Spacing — 0.65" top-to-top

Numbered and bullet list items use one textbox per item. Place each item's top 0.65" below the previous item's top (i.e., `top += inches(0.65)`). This is the canonical interval from `num_item()` and `bul_item()` helpers.

### Docx

| After element | Space |
|---------------|-------|
| Part header banner | `doc.add_paragraph()` (one blank paragraph) |
| Callout box | `doc.add_paragraph()` (one blank paragraph) |
| Code block | `doc.add_paragraph()` (one blank paragraph) |
| H1 heading (space_before / after) | 18pt / 8pt |
| H2 heading (space_before / after) | 14pt / 6pt |
| Activity step (space_before / after) | 2pt / 5pt |
| Source entry (space_before / after) | 2pt / 5pt |
| Callout label paragraph (space_after) | 20pt |
| Callout additional lines (space_after) | 20pt |

### Slides

| Margin | Value |
|--------|-------|
| Slide edge safe zone — left/right | `inches(0.50)` (`space-2xl`) |
| Slide edge safe zone — top/bottom | `inches(0.40)` (`space-xl`) |
| Between badge and title text (part_slide_header) | `inches(0.15)` (`space-md`) |
| Body content top after part_slide_header | `inches(1.38)` |
| Between title and body content (other slides) | `inches(0.25)` (`space-lg`) |
| **Minimum gap between any two body elements** | **`inches(0.15)` (`space-md`) — hard floor; never place a textbox top less than 0.15" below the previous textbox bottom** |
| Tight heading-to-body gap (heading directly above its own item) | `inches(0.10)` (`space-sm`) — only when a heading sits immediately above its own label. Do NOT use for sibling body items. |
| Standard section gap (before/after code blocks, between sections) | `inches(0.25)` (`space-lg`) |
| Callout box (tip/warn): vertical padding top and bottom | `inches(0.15)` each — set `tf.margin_top = Emu(0)` and `tf.margin_bottom = Emu(0)` so the box's `pad_v` is the only source of vertical spacing |
| Step/prompt row height | `inches(0.88)` — tight enough to avoid excess whitespace, generous enough not to clip wrapped text |
| Q&A pair inter-pair gap | `inches(0.15)` — use single textbox per pair (see Q&A slide pattern below), row_h − box_h = 0.15" |
| Troubleshooting / numbered list items | Consolidate all items into ONE textbox; use `add_para(tf, item, space_before=10)` between items — never individual textboxes per item (their box gaps produce inconsistent visual spacing) |
