# WordPress Meetup Activity Creator — Prompts Package

This package contains everything you need to run the WordPress Meetup Activity Creator with any AI provider — Claude, ChatGPT, Gemini, or others.

---

## What's included

```
system-prompt.md          The main agent instructions — paste into your AI's system prompt field
context/
  STYLE_GUIDE.md          Design rules, colors, typography, Python helpers (attach as context)
  knowledge-base.md       Official WordPress resources and source quality rules (attach as context)
  v3_slide_helpers.py     Shared Python library for slide decks (copy to your working directory)
README.md                 This file
```

---

## Setup instructions by provider

### Claude (claude.ai or API)

**In Claude.ai Projects:**
1. Create a new Project
2. In Project Settings → Instructions, paste the full contents of `system-prompt.md`
3. Upload `STYLE_GUIDE.md` and `knowledge-base.md` to the Project's knowledge base
4. Copy `v3_slide_helpers.py` to the directory where you'll run build scripts
5. Start a new conversation in the project and say: "Create a new WordPress meetup activity"

**Via the Anthropic API:**
- Place `system-prompt.md` content in the `system` parameter
- Attach `STYLE_GUIDE.md` and `knowledge-base.md` as document blocks in the first user message
- Model recommendation: `claude-opus-4-6` or `claude-sonnet-4-6`

---

### ChatGPT (OpenAI)

**In a Custom GPT:**
1. Go to https://chat.openai.com/gpts/editor
2. Paste `system-prompt.md` contents into the **Instructions** field
3. Upload `STYLE_GUIDE.md` and `knowledge-base.md` in the **Knowledge** section
4. Under **Capabilities**, enable Code Interpreter (required for running Python build scripts)
5. Copy `v3_slide_helpers.py` to your working directory
6. Save and start a conversation: "Create a new WordPress meetup activity"

**In a standard ChatGPT conversation:**
1. Start a new chat
2. Paste `system-prompt.md` as your first message, prefixed with: "Please act as the following agent:"
3. In the same message, attach `STYLE_GUIDE.md` and `knowledge-base.md` as file uploads
4. Follow with: "I'd like to create a new WordPress meetup activity."

**Note on code execution:** ChatGPT's Code Interpreter runs Python in a sandboxed environment. The build scripts will run, but file paths will be inside OpenAI's sandbox. Download the generated files from the Code Interpreter session.

---

### Gemini (Google)

**In Gemini Advanced / Gems:**
1. Go to https://gemini.google.com/gems
2. Create a new Gem
3. Paste `system-prompt.md` contents into the **Instructions** field
4. Upload `STYLE_GUIDE.md` and `knowledge-base.md` as reference documents
5. Name the Gem "WordPress Activity Creator" and save
6. Copy `v3_slide_helpers.py` to your working directory

**In a standard Gemini conversation:**
1. Open a new conversation with Gemini Advanced (1.5 Pro or later recommended — large context window needed for STYLE_GUIDE.md)
2. Upload `STYLE_GUIDE.md`, `knowledge-base.md`, and `v3_slide_helpers.py` as file attachments
3. Paste `system-prompt.md` as your first message
4. Follow with your activity request

**Note:** Gemini does not execute code directly. It will write the Python build scripts, which you run locally.

---

### Any other provider

1. Find the **system prompt / system instructions** field in your provider's interface (sometimes called "custom instructions," "persona," or "AI context")
2. Paste the full contents of `system-prompt.md`
3. Attach or paste `STYLE_GUIDE.md` and `knowledge-base.md` as additional context at the start of your conversation
4. Copy `v3_slide_helpers.py` to your local working directory
5. Run the Python build scripts locally — the AI writes them, you execute them

**Minimum context window:** The full context (system prompt + STYLE_GUIDE.md) is approximately 70,000 tokens. Use a model with at least a 100K context window for best results.

---

## What the AI will do

When you start a conversation, the agent:

1. **First time only:** Walks you through a setup checklist — checks Python dependencies, LibreOffice, and confirms your output directory
2. **Every activity:** Asks for topic and audience level → researches official WordPress sources → flags any design decisions → presents an outline for your approval → writes Python build scripts → runs them → does visual QA on every slide → delivers the files

### To create an activity, say something like:
- "Create a meetup activity on WordPress Playground for beginners"
- "Build an activity kit on WordPress security for intermediate users"  
- "New activity: Full Site Editing for designers"
- "Add an activity on WooCommerce to the library"

---

## Running the build scripts

The AI writes two Python scripts per activity. Run them in your terminal:

```bash
# Make sure you're in the directory containing v3_slide_helpers.py
python build_<topic>_facilitator_guide.py
python build_<topic>_slides.py
```

**For PDF export** (requires LibreOffice):
```bash
# macOS / Linux
soffice --headless --convert-to pdf "path/to/Slides.pptx"
soffice --headless --convert-to pdf "path/to/Facilitator Guide.docx"
```

**Required Python packages:**
```bash
pip install python-docx python-pptx
```

---

## Technical notes

**Why v3_slide_helpers.py is separate**
The helpers library (~600 lines) provides all the layout primitives for slides — section bars, step formatters, table builders, callout boxes, WCAG color constants, and speaker note handling. Every slide build script imports it. It has no external dependencies beyond python-pptx.

**Why the system prompt doesn't include the STYLE_GUIDE**
The STYLE_GUIDE is 1,200+ lines of Python code and design rules. Keeping it as a separate attachment means you can update it independently without editing the system prompt, and providers with file upload can handle it more efficiently than embedding it inline.

**WCAG 2.2 AA compliance**
The agent enforces WCAG AA on every slide deck. The main rules it checks:
- All text on dark backgrounds must be white (#FFFFFF) — grey on black fails AA
- Body text minimum 14pt on slides
- Callout boxes sized to prevent text clipping
- Resources table labels explicitly set to non-bold

---

## License

Free to use, adapt, and share. Built for the WordPress community.
